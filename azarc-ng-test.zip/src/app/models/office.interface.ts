export interface Office {
  id: number;
  name: string;
}
